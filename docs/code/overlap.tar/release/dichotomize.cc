#include <cmath>
#include <vector>
#include <string>
#include <fstream>
#include <string.h>
#include <iostream>
#include <algorithm>
#include <inttypes.h>
#include <sys/time.h>
#include <time.h>
#ifdef __APPLE__
#include <unordered_map>
#include <unordered_set>
#else
#include <tr1/unordered_map>
#include <tr1/unordered_set>
#endif

using namespace std;
#ifndef __APPLE__
using namespace tr1;
#endif

#define RATIO 0.005
#define TIMES 200

struct combination;

int c, n;
int total_eles;
int alive_id = 0;
uint64_t heap_op = 0;
int64_t large_cost = 0;
int64_t large_est_cost = 0;
vector<int> heap;
vector<combination> combs;
vector<pair<int, int>> buck;
vector<vector<int>> dataset;
vector<vector<int>> records;
vector<pair<int, int>> idmap;
unordered_set<int> random_ids;
vector<vector<pair<int, int>>> ele_lists;

double heap_cost;
double binary_cost;
int list_max;
int list_min;
int64_t list_cost;
int64_t list_sum;
int64_t list_sample_num;
int64_t result_num;
int64_t candidate_num;

void readFile(char* filename);
bool comp_int(const int a, const int b);
bool comp_comb(const int a, const int b);
bool comp_pair(const pair<int, int> &p1, const int val);
bool is_equal(const combination & c1, const combination & c2);
int64_t small_estimate(int L, int R);
int64_t large_estimate(int L, int R);
uint64_t getListCost();
int divide(int nL);

struct combination {

  int N;
  int id;
  bool completed;
  vector<int> curr;

  combination(int d, int beg)
    : completed(false ), id(d), N(dataset[d].size()) {
      if (N < 1 || c > N) completed = true;
      for (auto i = 0; i < c; ++i)
        curr.push_back(beg + 1 + i);
    }

  // compute next combination
  void next() {
    int i = c - 1;
    while (i >= 0 && curr[i] == N - c + i) --i;
    if (i < 0) completed = true;
    else {
      int temp = curr[i];
      for (int j = i; j <= c - 1; j++)
        curr[j] = temp + 1 + j - i;
    }
  }

  void print() const {
    cout << "combination from " << id << " : ";
    for (auto j = 0; j < c; j++)
      cout << dataset[id][curr[j]] << " ";
    cout << " ----> ";
    for (auto j = 0; j < c; j++)
      cout << curr[j] << " ";
    cout << endl;
  }

  bool stepback(int i) {
    if (i == 0) return true;
    curr[i - 1]++;
    if (curr[i - 1] + c - 1 - i + 1 >= N)
      return stepback(i - 1);
    for (int j = i; j < c; j++)
      curr[j] = curr[i - 1] + j - i + 1;
    return false;
  }

  void binary(const combination & value) {
    auto it = dataset[id].begin() + curr[0];
    for (int i = 0; i < c; i++) {
      // find the first one not larger than the value
      it = lower_bound(it, dataset[id].end(), dataset[value.id][value.curr[i]], comp_int);
      // if get the end, we will increase the last one by 1 and set the rest as max
      if (it == dataset[id].end()) {
        completed = stepback(i);
        return;
        // if we get the same value, we fill in it
      } else if (*it == dataset[value.id][value.curr[i]]) {
        curr[i] = distance(dataset[id].begin(), it);
        // if we get the smaller value, we set the rest as max
      } else {
        curr[i] = distance(dataset[id].begin(), it);
        if (curr[i] + c - 1 - i >= N) {
          completed = stepback(i);
          return;
        }
        for (int j = i + 1; j < c; j++)
          curr[j] = curr[i] + j - i;
        return;
      }
    }
    return;
  }
};

int64_t nchoosek(int64_t n, int64_t k) {
  if (k == 0) return 1;
  return (n * nchoosek(n - 1, k - 1)) / k;
}

void small_case(int L, int R) {
  if (L >= R) return;
  --c;

  timeval beg, mid, mid1, end;
  gettimeofday(&beg, NULL);

  cout << " number of small sets: " << R - L << endl;

  list_cost = 0;
  heap_cost = 0;
  binary_cost = 0;
  vector<vector<int>> res_lists;

  gettimeofday(&mid, NULL);

  for (auto idx = total_eles - 1; idx >= 0; idx--) {
    if (ele_lists[idx].size() < 2) continue;
    vector<pair<int,int>> & vec = ele_lists[idx];
    int size = distance(vec.begin(), lower_bound(vec.begin(), vec.end(), L, comp_pair));
    if (vec.size() <= size + 1) continue;

    // initialize heap and combinations
    heap.clear();
    combs.clear();
    int heap_size = 0;
    for (auto i = size; i < vec.size(); i++) {
      if ((int)(dataset[vec[i].first].size()) - 1 - vec[i].second < c) continue;
      heap.push_back(heap_size++);
      combs.push_back(combination(vec[i].first, vec[i].second));
    }

    if (heap_size < 2) continue;
    make_heap(heap.begin(), heap.end(), comp_comb);
    heap_cost += (3 * c * heap_size);
    // cout << heap_size << " initial: " << heap_cost << endl;

    // pop heaps
    vector<int> inv_list;
    while (heap_size > 1) {
      inv_list.clear();
      do {
        heap_cost += (c * log2(heap_size) + c);
        // cout << heap_size << " " << heap_cost << endl;
        pop_heap(heap.begin(), heap.begin() + heap_size, comp_comb);
        --heap_size;
        inv_list.push_back(combs[heap[heap_size]].id);
      } while (heap_size > 0 && is_equal(combs[heap[heap_size]], combs[heap.front()]));

      if (inv_list.size() > 1) {
        list_cost += ((inv_list.size() - 1) * (int64_t)inv_list.size() / 2);
        res_lists.push_back(std::move(inv_list));
      }

      if (heap_size == 0) break;

      for (auto i = heap_size; i < heap.size(); ++i) {
        combs[heap[i]].binary(combs[heap.front()]);
        binary_cost += (c * log2(dataset[combs[heap[i]].id].size()));
      }

      int comp_num = 0;
      for (auto i = heap_size; i < heap.size(); ++i) {
        if (combs[heap[i]].completed)
          ++comp_num;
        else if (comp_num > 0)
          heap[i - comp_num] = heap[i];
      }

      for (auto i = heap_size; i < (int)heap.size() - comp_num; i++) {
        push_heap(heap.begin(), heap.begin() + i + 1, comp_comb);
        heap_cost += (c * log2(i));
      }
      while (comp_num-- > 0)
        heap.pop_back();
      heap_size = heap.size();
    }
  }

  cout << "Res lists num: " << res_lists.size() << endl;

  gettimeofday(&mid1, NULL);

  vector<vector<int>> id_lists(n);
  for (auto i = 0; i < res_lists.size(); i++) {
    for (auto j = 0; j < res_lists[i].size(); j++)
      id_lists[res_lists[i][j]].push_back(i);
  }

  vector<int> results(n, -1);
  for (auto i = n - 1; i >= 0; i--) {
    if (id_lists[i].empty()) continue;
    for (auto j = 0; j < id_lists[i].size(); j++) {
      res_lists[id_lists[i][j]].pop_back();
      for (auto k = 0; k < res_lists[id_lists[i][j]].size(); k++) {
        if (results[res_lists[id_lists[i][j]][k]] != i) {
          // cout << idmap[i].first << " " << idmap[res_lists[id_lists[i][j]][k]].first << endl;
          results[res_lists[id_lists[i][j]][k]] = i;
          ++result_num;
        }
      }
    }
  }
  ++c;
  gettimeofday(&end, NULL);
  cout << " small p1 : " << mid.tv_sec - beg.tv_sec + (mid.tv_usec - beg.tv_usec) / 1e6 << endl;
  cout << " small p2 : " << mid1.tv_sec - mid.tv_sec + (mid1.tv_usec - mid.tv_usec) / 1e6 << endl;
  cout << " small p3 : " << end.tv_sec - mid1.tv_sec + (end.tv_usec - mid1.tv_usec) / 1e6 << endl;
  cout << " heap, binary, list costs : " << heap_cost << " " << binary_cost << " " << list_cost << endl;
}

void large_case(int L, int R) {
  timeval beg, mid, end;
  gettimeofday(&beg, NULL);

  vector<vector<int>> ele(total_eles);

  for (int i = n - 1; i >= R; --i)
    for (auto x : dataset[i])
      ele[x].push_back(i);

  gettimeofday(&mid, NULL);
  vector<int> bucket;

  for (int i = R - 1; i >= L; --i) {

    int count = 0;
    for (auto x : dataset[i]) count += ele[x].size();
    large_cost += count;

    if (count > 0.2 * n) {
      // n + count * value + count * if
      bucket.assign(n, 0);
      for (auto x : dataset[i]) {
        for (auto id : ele[x]) {
          if (++bucket[id] == c) {
            // cout << idmap[i].first << " " << idmap[id].first << endl;
            ++result_num;
          }
        }
      }
    } else {
      // count * if + count * value + count * if or value
      alive_id++;
      for (auto x : dataset[i]) {
        for (auto id : ele[x]) {
          if (buck[id].first != alive_id) {
            buck[id].first = alive_id;
            buck[id].second = 1;
          } else {
            if (++buck[id].second == c) {
              // cout << idmap[i].first << " " << idmap[id].first << endl;
              ++result_num;
            }
          }
        }
      }
    }
    for (auto x : dataset[i])
      ele[x].push_back(i);
  }
  gettimeofday(&end, NULL);
  cout << " large p1 : " << mid.tv_sec - beg.tv_sec + (mid.tv_usec - beg.tv_usec) / 1e6 << endl;
  cout << " large p2 : " << end.tv_sec - mid.tv_sec + (end.tv_usec - mid.tv_usec) / 1e6 << endl;
}

// return the bound position
int estimate() {

  // get random elements for sampling
  while (random_ids.size() < total_eles * RATIO)
    random_ids.insert(rand() % total_eles);

  int64_t small, large;
  int min_size = dataset.back().size();
  int max_size = dataset.front().size();
  auto bound = (min_size <= c ? c : min_size);
  int pos = divide(bound);
  int prev_pos = pos;
  int64_t prev_large = large_estimate(0, pos);
  int64_t prev_small = small_estimate(pos, n);
  ++bound;

  for (; bound <= max_size; bound++) {

    pos = divide(bound);
    if (pos == prev_pos) continue;
    cout << endl << "size boud: " << bound << endl;
    cout << "larg numb: " << pos << endl;
    cout << "smal numb: " << n - pos << endl;

    large = large_estimate(0, pos);
    small = small_estimate(pos, n);

    cout << "heap cost: " << heap_cost * TIMES << endl;
    cout << "biny cost: " << binary_cost * TIMES << endl;
    cout << "list cost: " << list_cost << endl; 
    cout << "smal cost: " << small << endl;
    cout << "larg cost: " << large << endl;

    if (small - prev_small > 1.2 * (prev_large - large)) return prev_pos;

    prev_pos = pos;
    prev_large = large;
    prev_small = small;
  }
  return prev_pos;
}

int main(int argc, char ** argv) {
  srand(time(NULL));
  
  timeval starting, ending, s1, t1, s2, t2;
  timeval time1, time2, time3, time4;

  gettimeofday(&starting, NULL);

  readFile(argv[1]); // read in data into records
  c = atoi(argv[2]); // get threshold
  n = records.size(); // get number of records
  buck.assign(n, make_pair(0, 0)); // for counting

  vector<pair<int, int>> eles;
  unordered_map<int, vector<int>> ele;

  for (int i = 0; i < records.size(); i++) {
    if (records[i].size() < c) continue;  // remove records with size smaller than c
    for (int j = 0; j < records[i].size(); j++)  // build inverted index
      ele[records[i][j]].push_back(i);
  }

  for (auto it = ele.begin(); it != ele.end(); it++)
    eles.push_back(make_pair(it->first, it->second.size()));  // build element frequency table

  // get global order: frequency increasing order
  sort(eles.begin(), eles.end(), [](const pair<int, int> &p1, const pair<int, int> &p2) {
    return p1.second < p2.second;
  });

  // container initialize
  dataset.resize(n);

  // sort elements by its global order: frequence increasing order
  // remove widow word
  // encode elements in decreasing order
  total_eles = eles.size();
  for (auto i = 0; i < int(eles.size()); ++i) {
    if (eles[i].second < 2) continue;
    for (auto j = ele[eles[i].first].begin(); j != ele[eles[i].first].end(); j++)
      dataset[*j].push_back(total_eles - i - 1);
  }

  gettimeofday(&time1, NULL);
  cout << "Initial Time: " << time1.tv_sec - starting.tv_sec + (time1.tv_usec - starting.tv_usec) / 1e6 << endl;

  // ****** cost model for prefix length selection ******
  // remove short records
  for (auto i = 0; i < n; i++)
    if (dataset[i].size() < c) dataset[i].clear();

  // create id mappings: from sorted to origin
  for (auto i = 0; i < n; i++)
    idmap.push_back(make_pair(i, dataset[i].size()));

  // sort records by length in decreasing order
  sort(idmap.begin(), idmap.end(), [] (const pair<int, int> & a, const pair<int, int> & b) {
      return a.second > b.second;
  });
  sort(dataset.begin(), dataset.end(), [] (const vector<int>& a, const vector<int>& b) {
      return a.size() > b.size();
  });
  cout << " largest set: " << dataset.front().size() << " smallest set: " << dataset.back().size() << endl;

  // build real inverted index
  ele_lists.resize(total_eles);
  for (int i = 0; i < n; i++)
    for (int j = 0; j < dataset[i].size(); j++)
      ele_lists[dataset[i][j]].push_back(make_pair(i,j));

  gettimeofday(&time3, NULL);
  cout << "Transform Time: " << time3.tv_sec - time1.tv_sec + (time3.tv_usec - time1.tv_usec) / 1e6 << endl;

  // ****** cost model for boundary selection ******
  int nL = estimate();
  int nP = nL;
  cout << " large sets: " << nP << " small sets: " << n - nP << endl;

  gettimeofday(&time4, NULL);
  cout << "Estimation Time: " << time4.tv_sec - time3.tv_sec + (time4.tv_usec - time3.tv_usec) / 1e6 << endl;

  // ****** conduct joining ******  
  result_num = 0;
  candidate_num= 0;

  gettimeofday(&s1, NULL);
  large_case(0, nP);
  gettimeofday(&t1, NULL);

  gettimeofday(&s2, NULL);
  small_case(nP, n);
  gettimeofday(&t2, NULL);

  gettimeofday(&ending, NULL);
  cout << "Join Time: " << ending.tv_sec - time4.tv_sec + (ending.tv_usec - time4.tv_usec) / 1e6 << endl;
  cout << "  large Time: " << t1.tv_sec - s1.tv_sec + (t1.tv_usec - s1.tv_usec) / 1e6 << endl;
  cout << "  small Time: " << t2.tv_sec - s2.tv_sec + (t2.tv_usec - s2.tv_usec) / 1e6 << endl;
  cout << "All Time: " << ending.tv_sec - starting.tv_sec + (ending.tv_usec - starting.tv_usec) / 1e6 << endl;
  cout << "Result Num: " << result_num << endl;
  cout << "  large cost: " << large_cost << " small cost: " << heap_cost + list_cost + binary_cost << endl;
  return 0;
}

int64_t small_estimate(int L, int R) {
  if (L >= R) return 0;
  
  timeval beg, mid, mid1, end;
  gettimeofday(&beg, NULL);

  int total_num = R - L;
  int sample_time = (R - L);
  double ratio =  (total_num - 1) * 1.0 / sample_time * total_num / 2;
  // cout << "sample ratio: " << ratio << endl;
  int r1, r2;
  int64_t pair_num = 0;
  for (auto i = 0; i < sample_time; i++) {
    do {
      r1 = rand() % (R - L) + L;
      r2 = rand() % (R - L) + L;
    } while (r1 == r2);
    int start1 = 0;
    int start2 = 0;
    int overlap = 0;
    while (start1 < dataset[r1].size() && start2 < dataset[r2].size()) {
      if (dataset[r1][start1] == dataset[r2][start2]) {
        ++start1, ++start2;
        overlap++;
      } else {
        if (dataset[r1][start1] > dataset[r2][start2]) ++start1;
        else ++start2;
      }
    }
    if (overlap >= c){
      // cout << overlap << " " << c << endl;
      pair_num += nchoosek(overlap, c);
      // cout << pair_num << endl;
    }
  }
  list_cost = pair_num * ratio;

  --c;

  heap_cost = 0;
  binary_cost = 0;

  gettimeofday(&mid, NULL);

  for (auto sit = random_ids.begin(); sit != random_ids.end(); ++sit) {
    auto idx = *sit;

    vector<pair<int,int>> & vec = ele_lists[idx];
    int size = distance(vec.begin(), lower_bound(vec.begin(), vec.end(), L, comp_pair));
    if (vec.size() <= size + 1) continue;

    heap.clear();
    combs.clear();
    int heap_size = 0;
    for (auto i = size; i < vec.size(); i++) {
      if ((int)(dataset[vec[i].first].size()) - 1 - vec[i].second < c) continue;
      heap.push_back(heap_size++);
      combs.push_back(combination(vec[i].first, vec[i].second));
    }

    if (heap_size < 2) continue;

    make_heap(heap.begin(), heap.end(), comp_comb);
    heap_cost += (3 * c * heap_size);

    while (heap_size > 1) {
      do {
        ++heap_op;
        heap_cost += (c * log2(heap_size) + c);
        pop_heap(heap.begin(), heap.begin() + heap_size, comp_comb);
        --heap_size;
      } while (heap_size > 0 && is_equal(combs[heap[heap_size]], combs[heap.front()]));

      if (heap_size == 0) break;

      for (auto i = heap_size; i < heap.size(); ++i) {
        combs[heap[i]].binary(combs[heap.front()]);
        binary_cost += (c * log2(dataset[combs[heap[i]].id].size()));
      }

      int comp_num = 0;
      for (auto i = heap_size; i < heap.size(); ++i) {
        if (combs[heap[i]].completed)
          ++comp_num;
        else if (comp_num > 0)
          heap[i - comp_num] = heap[i];
      }

      for (auto i = heap_size; i < (int)heap.size() - comp_num; i++) {
        push_heap(heap.begin(), heap.begin() + i + 1, comp_comb);
        heap_cost += (c * log2(i));
      }
      while (comp_num-- > 0)
        heap.pop_back();
      heap_size = heap.size();
    }
  }

  ++c;

  gettimeofday(&end, NULL);
  cout << " small est time p1 : " << mid.tv_sec - beg.tv_sec + (mid.tv_usec - beg.tv_usec) / 1e6 << endl;
  cout << " small est time p2 : " << end.tv_sec - mid.tv_sec + (end.tv_usec - mid.tv_usec) / 1e6 << endl;
  return binary_cost * TIMES + heap_cost * TIMES + list_cost;
}

/*
int64_t large_estimate(int L, int R) {
  int64_t ret = 0;
  for (int x = 0; x < ele_lists.size(); x++) {
    int large_num = distance(ele_lists[x].begin(), lower_bound(ele_lists[x].begin(), ele_lists[x].end(), R, comp_pair));
    int all_num = ele_lists[x].size();
    ret += (large_num * all_num - large_num * (large_num - 1) / 2);
  }
  large_est_cost = ret;
  return ret;
}
*/

int64_t large_estimate(int L, int R) {
  timeval beg, end;
  gettimeofday(&beg, NULL);
  vector<int> count(total_eles);
  for (int i = n - 1; i >= R; --i)
    for (auto x : dataset[i])
      ++count[x];

  int64_t ret = 0;
  for (int i = R - 1; i >= L; --i) {
    for (auto x : dataset[i]) {
        ++count[x];
        ret += count[x];
    }
  }
  large_est_cost = ret;
  gettimeofday(&end, NULL);
  cout << " large est time : " << end.tv_sec - beg.tv_sec + (end.tv_usec - beg.tv_usec) / 1e6 << endl;
  return ret;
}

uint64_t getListCost() {
  return (list_cost - list_sum) / 2 * TIMES;
  // return (list_cost - (list_sum * 1.0 / list_sample_num) * (list_sum * 1.0 / list_sample_num) - list_sum) / 2 * TIMES;
  // return (list_cost * list_sample_num * 1.0 / (list_sample_num - 1) - list_sum * 1.0 / list_sample_num * list_sum / (list_sample_num - 1) - list_sum) / 2 * TIMES; 
}

// find first set with size smaller or equal to nL
int divide(int nL) {
  int l = 0, r = n;
  while (l < r) {
    int m = (l + r) >> 1;
    if (dataset[m].size() > nL) l = m + 1;
    else r = m;
  }
  return r;
}

bool comp_pair(const pair<int, int> &p1, const int val) {
  return p1.first < val;
}

bool comp_int(const int a, const int b) {
  return a > b;
}

bool comp_comb(const int a, const int b) {
  combination & c1 = combs[a];
  combination & c2 = combs[b];
  for (int i = 0; i < c; i++) {
    if (dataset[c1.id][c1.curr[i]] > dataset[c2.id][c2.curr[i]])
      return false;
    else if (dataset[c1.id][c1.curr[i]] < dataset[c2.id][c2.curr[i]])
      return true;
  }
  return c1.id > c2.id;
}

bool is_equal(const combination & c1, const combination & c2) {
  for (int i = 0; i < c; i++) {
    if (dataset[c1.id][c1.curr[i]] != dataset[c2.id][c2.curr[i]])
      return false;
  }
  return true;
}

void readFile(char* filename) {
  FILE *fp = fopen(filename, "r");
  fseek(fp, 0, SEEK_END);
  int sz = ftell(fp);
  rewind(fp);
  char *buffer = (char*) malloc(sizeof(char) * (sz + 1));
  sz = fread(buffer, 1, sz, fp);
  buffer[sz] = '\0';

  vector<int> rec;
  int num = 0;
  bool empty = true;
  for (char* c = buffer; ; ++c) {
    if (*c == '\0' || isspace(*c)) {
      if (!empty) {
        rec.push_back(num);
        empty = true;
        num = 0;
      }
      if (*c == '\0' || *c == '\n' || *c == '\r') {
        if (!rec.empty()) {
          // lengthSum += rec.size();
          records.push_back(rec);
          rec.clear();
        }
        if (*c == '\0') break;
      }
    } else {
      empty = false;
      num = (num << 3) + (num << 1) + *c - '0';
    }
  }
}

