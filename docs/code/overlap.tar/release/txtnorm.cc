#include <fstream>
#include <iostream>
#include <vector>
#include <tr1/unordered_map>
#include "google/dense_hash_map"
#include <string>
#include <ctype.h>
#include <algorithm>

using namespace std;
using namespace tr1;

#define google_unordered_map google::dense_hash_map

void strToTokens(const string &s, vector<string> &res, const string &delims) {
	string::size_type begIdx, endIdx;
	begIdx = s.find_first_not_of(delims);
	while (begIdx != string::npos) {
		endIdx = s.find_first_of(delims, begIdx);
		if (endIdx == string::npos)
			endIdx = s.length();
		res.push_back(s.substr(begIdx, endIdx - begIdx));
		begIdx = s.find_first_not_of(delims, endIdx);
	}
}

// 对每个token，转换为tid。
// 如果是新的token，自增tid，插入字典dictionary中。
// 否则，测试这个token是否在当前的记录中已经出现过
// recent纪录了对一个tid，最近包含它的rid
// 如果这个tid在recent中最近包含它的rid和当前rid相同，代表出现过。否则，没有出现，do nothing
// 如果已经出现过，second代表应当把tid转换为另外一个tid，重复以


int main(int argc, char ** argv) {
	string str;
	string delim = " .,:;?!\t";
	ifstream datafile(argv[1], ios::in);
	unordered_map<string, int> dictionary;
  // dictionary.set_empty_key(NULL);

	vector<pair<int, int>> recent;
	vector<vector<int>> records;
	int tid = 0;  // the maximum token id
	int rid = 0;  // current record id

	while (getline(datafile, str)) {
	
		vector<string> tokens;
#ifdef _NORM_
    for (int i = 0; i < str.length(); i++) {
      str[i] = tolower(str[i]);
      if (!isalnum(str[i])) str[i] = ' ';
    }
#endif

#ifdef _NGRAM_
    int q = atoi(argv[2]);
    bool f = true;
    for (auto sit = str.begin(); sit != str.end();) {
      if (*sit == ' ' && f == true) {
        sit = str.erase(sit);
        continue;
      }
      else if (f == true)
        f = false;
      else
        f = true;
      ++sit;
    }
    for (int i = 0; i < (int)str.length() - q + 1; i++) {
      tokens.push_back(str.substr(i ,q));
    }
#else
		strToTokens(str, tokens, delim);
#endif
		vector<int> record;

		for (int i = 0; i < tokens.size(); i++) {
			auto dit = dictionary.find(tokens[i]);
			if (dit == dictionary.end()) {
				dictionary[tokens[i]] = tid;  // map a string token to an token id
				recent.push_back(make_pair(rid, -1));  // the recent record to this new token id is rid
				record.push_back(tid);
				tid = tid + 1;
			} else {
				int ctid = dit->second;
				while (recent[ctid].first == rid) {
					if (recent[ctid].second == -1) {
						recent[ctid].second = tid;
						recent.push_back(make_pair(rid, -1));
						ctid = tid;
						tid = tid + 1;
						break;
					} else {
						ctid = recent[ctid].second;
					}
				}
				recent[ctid].first = rid;
				record.push_back(ctid);
			}
		}
		records.push_back(record);
		rid++;
	}
	sort(records.begin(), records.end(), [](const vector<int> &a, const vector<int> &b) {
		return a.size() < b.size(); 
	});
	for (int i = 0; i < records.size(); i++) {
		for (int j = 0; j < records[i].size(); j++)
			printf("%d ", records[i][j]);
		printf("\n");
	}
}
